module.exports = {
    bot_token: "OTg4MDM4MzM1NTUxMzkzODgy.GqS5fL.JgH-4lJhvhyczdrVj3MkUxQrPvTbs-FzrikM5Q",
    bot_client_id: "988038335551393882",
    bot_prefix: '!',

    attachments_path: 'Attachments',
    debug: true,

    database: {
        mongodb_user: '',
        mongodb_password: '',
        mongodb_host: '',
        mongodb_port: '',
        mongodb_base: ''
    }
};
